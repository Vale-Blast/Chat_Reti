import java.io.IOException;
import java.util.Scanner;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;
import java.net.DatagramSocket;
import java.util.Calendar;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.Cipher;


/**
 * Simple test for a Client with message encrypting
 */
public class Client {

    public static void send(String address, int port, String message) {

				try {
						
						// Check if the pair of keys are present else generate those.
      			if (!areKeysPresent()) {
						  	generateKey();
      			}

						// Crittaggio messaggio da inviare
						ObjectInputStream inputStream = null;
						EncryptionUtil crypto = new EncryptionUtil();
						inputStream = new ObjectInputStream(new FileInputStream(crypto.PUBLIC_KEY_FILE));
						final PublicKey publicKey = (PublicKey) inputStream.readObject();
						final byte[] buff = crypto.encrypt(message, publicKey);
						System.out.println("Criptato: " + buff.toString());

						// Test di decrittaggio sul client e stampa a video
						inputStream = new ObjectInputStream(new FileInputStream(crypto.PRIVATE_KEY_FILE));
						final PrivateKey privateKey = (PrivateKey) inputStream.readObject();
						final String plainText = crypto.decrypt(buff, privateKey);
						System.out.println("Decriptato: " + plainText);
					

            DatagramPacket packet = new DatagramPacket(buff, buff.length, new InetSocketAddress(address, port));
            DatagramSocket socket = new DatagramSocket();
            socket.send(packet);
            Calendar now = Calendar.getInstance();
            String day = "";
            if (now.get(Calendar.DAY_OF_MONTH) < 10)
                day = "0";
            day = day + now.get(Calendar.DAY_OF_MONTH);
            String month = "";
            if (now.get(Calendar.MONTH) < 10)
                month = "0";
            month = month + now.get(Calendar.MONTH);
            String year = "" + now.get(Calendar.YEAR);
            String hours = "";
            if (now.get(Calendar.HOUR_OF_DAY) < 10)
                hours = "0";
            hours = hours + now.get(Calendar.HOUR_OF_DAY);
            String minutes = "";
            if (now.get(Calendar.MINUTE) < 10)
                minutes = "0";
            minutes = minutes + now.get(Calendar.MINUTE);
            String seconds = "";
            if (now.get(Calendar.SECOND) < 10)
                seconds = "0";
            seconds = seconds + now.get(Calendar.SECOND);
            System.out.println("S[" + day + "/" + month + "/" + year + " " + hours + ":" + minutes + ":" + seconds + "]" + message + "\n");
        } catch (Exception e) { //catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        while(true) {
            Scanner sc = new Scanner(System.in);
            String line = sc.nextLine();
            send("127.0.0.1", 25023, line);
        }
    }
}
