import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.Cipher;

/**
 * Simple test for a Server with message encrypting
 */
public class Server {
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket(25023);
            byte[] buff;
            DatagramPacket packet;
            while(true) {
                buff = new byte[256];
                packet = new DatagramPacket(buff, buff.length);
                try {
                    socket.receive(packet); // receive
										
										/** I am receiving from local host, so I do not check if the
										 *  keys are present, because, instead, they are
                     */
										ObjectInputStream inputStream = null;
										EncryptionUtil crypto = new EncryptionUtil();
										inputStream = new ObjectInputStream(new FileInputStream(crypto.PRIVATE_KEY_FILE));
										final PrivateKey privateKey = (PrivateKey) inputStream.readObject();
										final String plainText = crypto.decrypt(packet.getData(), privateKey);
               		  System.out.println("Messagio ricevuto: " + plainText);
										System.out.println("Messaggio ricevuto criptato: " + packet.getData().toString());
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }
}
